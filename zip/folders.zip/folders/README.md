start 7tsp GUI v0.6(2019).ee (change .ee in .exe)
and choose the 7z folder in 
[catppuccin\Catppuccin for Windows by niivu - MARCH 16\7tsp Themes]
and choos the pack that you want and remove the extension .remove so the file become an .7z file