import{a as t}from"../chunks/entry.Ay9AGNWj.js";export{t as start};
