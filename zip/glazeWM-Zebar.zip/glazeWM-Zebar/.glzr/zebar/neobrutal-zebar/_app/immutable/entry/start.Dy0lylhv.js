import{a as t}from"../chunks/entry.Bq1dCMQ3.js";export{t as start};
