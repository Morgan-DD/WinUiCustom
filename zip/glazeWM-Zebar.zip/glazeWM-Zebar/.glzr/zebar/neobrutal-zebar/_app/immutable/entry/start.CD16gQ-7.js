import{a as t}from"../chunks/entry.BjA6Zqb0.js";export{t as start};
