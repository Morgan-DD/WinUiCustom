import{a as t}from"../chunks/entry.VOizf7E9.js";export{t as start};
