import{a as t}from"../chunks/entry.BnZZnZrM.js";export{t as start};
