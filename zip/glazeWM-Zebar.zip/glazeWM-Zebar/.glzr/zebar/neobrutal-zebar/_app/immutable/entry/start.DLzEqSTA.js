import{a as t}from"../chunks/entry.CJGuDJ_F.js";export{t as start};
