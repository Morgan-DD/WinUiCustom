import{a as t}from"../chunks/entry.BSTcCtTq.js";export{t as start};
