import{a as t}from"../chunks/entry.BAkgFGxY.js";export{t as start};
