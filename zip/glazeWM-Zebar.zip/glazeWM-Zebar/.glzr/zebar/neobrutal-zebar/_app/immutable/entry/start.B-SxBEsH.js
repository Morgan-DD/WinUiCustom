import{a as t}from"../chunks/entry.DxwcERBO.js";export{t as start};
