import{a as t}from"../chunks/entry.ByBPWtMa.js";export{t as start};
