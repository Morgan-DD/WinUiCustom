import{a as t}from"../chunks/entry.ZD-bCm2F.js";export{t as start};
