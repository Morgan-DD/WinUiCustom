# Config for new Glazewm on Rust for Windows and Zebar

> Showcase:

Fullscreen V1:
![Screenshoot](https://github.com/user-attachments/assets/d4e947d5-4a3e-4561-a471-25c9a67f9aa2)
Fullscreen V2:
![Screenshoot1](https://github.com/user-attachments/assets/9e90f3f7-3a9c-413d-8b30-a1520ba09338)
